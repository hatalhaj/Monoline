# Monoline

Online shop for Monoline.

- `index.html`: the shop
- `admin.html`: the product dashboard (add, edit and delete products)
- `js/products.js`: the product list the shop reads
- `images/`: logo, banner and product photos
